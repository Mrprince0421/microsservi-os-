# sales-service/app/main.py
from http import HTTPStatus
from typing import Annotated
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, func, and_
from datetime import date
import httpx

from . import DB, models, schemas

app = FastAPI(
    title='Microserviço de Vendas',
    description='API para gerenciar vendas e relatórios de contabilidade.',
    version='1.0.0'
)

T_Session = Annotated[Session, Depends(DB.get_session)]

# --------------------------------------------------------------------------
# SIMULAÇÃO DE COMUNICAÇÃO ENTRE SERVIÇOS
# --------------------------------------------------------------------------
# No futuro, esta função fará uma chamada HTTP para o user-service
def get_current_user_placeholder():
    return {"id": 1}

T_CurrentUser = Annotated[dict, Depends(get_current_user_placeholder)]

# No futuro, estas funções farão chamadas HTTP para o product-service
async def get_product_from_service(product_id: int, user_id: int):
    # Simula a busca de um produto no serviço de produtos
    # Em um cenário real, usaria httpx.get(f'http://product-service:8002/products/{product_id}')
    print(f"Simulando busca pelo produto {product_id} para o usuário {user_id}")
    return {"id": product_id, "name": f"Produto {product_id}", "price": 10.50, "QT": 20, "user_id": user_id}

async def update_product_stock_in_service(product_id: int, new_quantity: int, user_id: int):
    # Simula a atualização de estoque no serviço de produtos
    print(f"Simulando atualização de estoque para produto {product_id}: nova quantidade {new_quantity}")
    return {"status": "success"}

# --------------------------------------------------------------------------

router = APIRouter(prefix='/sales', tags=['sales'])


@router.post(
    '/', status_code=HTTPStatus.CREATED, response_model=schemas.SalePublic
)
async def create_sale(
        sale: schemas.SaleSchema,
        session: T_Session,
        current_user: T_CurrentUser
):
    total_price = 0
    sale_items_to_create = []

    for item in sale.items:
        # Comunicação com o serviço de produtos para obter dados
        product = await get_product_from_service(item.product_id, current_user['id'])

        if not product:
            raise HTTPException(
                status_code=HTTPStatus.NOT_FOUND,
                detail=f'Produto com ID {item.product_id} não encontrado no serviço de produtos.'
            )
        if product['QT'] < item.QT:
            raise HTTPException(
                status_code=HTTPStatus.BAD_REQUEST,
                detail=f'Produto {product["name"]} não tem estoque suficiente.'
            )

        # Comunicação com o serviço de produtos para atualizar o estoque
        new_quantity = product['QT'] - item.QT
        await update_product_stock_in_service(product['id'], new_quantity, current_user['id'])

        sale_items_to_create.append(models.SaleItem(
            sale_id=0,  # Será preenchido depois
            product_id=product['id'],
            QT=item.QT,
            product_price=product['price']
        ))
        total_price += product['price'] * item.QT

    # Cria a venda no banco de dados do serviço de vendas
    db_sale = models.Sale(
        user_id=current_user['id'],
        total_price=total_price
    )
    session.add(db_sale)
    session.commit()
    session.refresh(db_sale)

    # Associa os itens à venda recém-criada
    for sale_item in sale_items_to_create:
        sale_item.sale_id = db_sale.id
        session.add(sale_item)

    session.commit()
    session.refresh(db_sale)

    return db_sale

# Outras rotas de relatórios (daily_report, report_by_period, etc.) podem ser adicionadas aqui
# ...

app.include_router(router)